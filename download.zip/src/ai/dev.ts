import { config } from 'dotenv';
config();

import '@/ai/flows/suggest-related-subtopics.ts';
import '@/ai/flows/generate-mind-map-structure.ts';